const express = require('express');
const cors = require('cors');
const path = require('path');
const db = require('./db/conn');

const Produto = require('./model/Produto');
const Venda = require('./model/Venda');
const ItemVenda = require('./model/ItemVenda');
const Carrinho = require('./model/Carrinho');
const ItemCarrinho = require('./model/ItemCarrinho');

// Relacionamentos do banco
Carrinho.hasMany(ItemCarrinho, { as: 'itens', onDelete: 'CASCADE' });
ItemCarrinho.belongsTo(Carrinho);
ItemCarrinho.belongsTo(Produto, { as: 'produto' });
Venda.hasMany(ItemVenda, { as: 'itens', onDelete: 'CASCADE' });
ItemVenda.belongsTo(Venda);
ItemVenda.belongsTo(Produto, { as: 'produto' });

const app = express();
app.use(cors({ origin: '*' }));
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

app.use('/Produto', require('./router/ProdutoRouter'));
app.use('/Carrinho', require('./router/CarrinhoRouter'));
app.use('/Venda', require('./router/VendaRouter'));

app.get('/', (_req, res) => res.json({ message: 'API da loja funcionando!' }));
app.use((err, _req, res, _next) => res.status(400).json({ message: err.message || 'Erro na requisição.' }));

const port = process.env.PORT || 5000;
db.sync()
  .then(() => app.listen(port, () => console.log(`API rodando na porta ${port}`)))
  .catch(err => console.error('Erro ao conectar/sincronizar o banco:', err));
