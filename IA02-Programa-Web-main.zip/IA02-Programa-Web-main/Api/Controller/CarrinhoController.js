const { Op } = require('sequelize');
const Carrinho = require('../model/Carrinho');
const ItemCarrinho = require('../model/ItemCarrinho');
const Produto = require('../model/Produto');

async function carregar(sessionId) {
  const carrinho = await Carrinho.findOne({
    where: { sessionId, status: 'aberto' },
    include: [{ model: ItemCarrinho, as: 'itens', include: [{ model: Produto, as: 'produto' }] }]
  });
  return carrinho;
}

module.exports = class CarrinhoController {
  static async get(req, res) {
    try {
      const sessionId = req.params.sessionId;
      let carrinho = await carregar(sessionId);
      if (!carrinho) {
        const novo = await Carrinho.create({ sessionId });
        carrinho = await carregar(sessionId);
      }
      return res.json(carrinho);
    } catch (err) { return res.status(500).json({ message: 'Erro ao consultar carrinho.', error: err.message }); }
  }

  static async add(req, res) {
    try {
      const { sessionId, produtoId, quantidade = 1 } = req.body;
      if (!sessionId || !produtoId || !Number.isInteger(Number(quantidade)) || Number(quantidade) < 1)
        return res.status(422).json({ message: 'Informe sessão, produto e quantidade válida.' });
      const produto = await Produto.findByPk(produtoId);
      if (!produto) return res.status(404).json({ message: 'Produto não encontrado.' });
      let carrinho = await Carrinho.findOne({ where: { sessionId, status: 'aberto' } });
      if (!carrinho) carrinho = await Carrinho.create({ sessionId });
      const [item, created] = await ItemCarrinho.findOrCreate({
        where: { CarrinhoId: carrinho.id, ProdutoId: produto.id },
        defaults: { quantidade: Number(quantidade) }
      });
      if (!created) await item.update({ quantidade: item.quantidade + Number(quantidade) });
      return res.status(200).json(await carregar(sessionId));
    } catch (err) { return res.status(500).json({ message: 'Erro ao adicionar item.', error: err.message }); }
  }

  static async update(req, res) {
    try {
      const { quantidade } = req.body;
      if (!Number.isInteger(Number(quantidade)) || Number(quantidade) < 1)
        return res.status(422).json({ message: 'A quantidade deve ser pelo menos 1.' });
      const item = await ItemCarrinho.findByPk(req.params.itemId);
      if (!item) return res.status(404).json({ message: 'Item não encontrado.' });
      await item.update({ quantidade: Number(quantidade) });
      const carrinho = await Carrinho.findByPk(item.CarrinhoId);
      return res.json(await carregar(carrinho.sessionId));
    } catch (err) { return res.status(500).json({ message: 'Erro ao atualizar item.', error: err.message }); }
  }

  static async remove(req, res) {
    try {
      const item = await ItemCarrinho.findByPk(req.params.itemId);
      if (!item) return res.status(404).json({ message: 'Item não encontrado.' });
      await item.destroy();
      return res.json({ message: 'Item removido do carrinho.' });
    } catch (err) { return res.status(500).json({ message: 'Erro ao remover item.', error: err.message }); }
  }

  static async clear(req, res) {
    try {
      const carrinho = await Carrinho.findOne({ where: { sessionId: req.params.sessionId, status: 'aberto' } });
      if (carrinho) await ItemCarrinho.destroy({ where: { CarrinhoId: carrinho.id } });
      return res.json({ message: 'Carrinho limpo.' });
    } catch (err) { return res.status(500).json({ message: 'Erro ao limpar carrinho.', error: err.message }); }
  }
};
