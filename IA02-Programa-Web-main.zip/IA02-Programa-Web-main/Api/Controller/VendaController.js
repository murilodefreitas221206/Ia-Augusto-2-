const db = require('../db/conn');
const Venda = require('../model/Venda');
const ItemVenda = require('../model/ItemVenda');
const Carrinho = require('../model/Carrinho');
const ItemCarrinho = require('../model/ItemCarrinho');
const Produto = require('../model/Produto');

module.exports = class VendaController {
  static async finalizar(req, res) {
    const { sessionId } = req.body;
    if (!sessionId) return res.status(422).json({ message: 'Identificador do carrinho obrigatório.' });
    const transaction = await db.transaction();
    try {
      const carrinho = await Carrinho.findOne({
        where: { sessionId, status: 'aberto' },
        include: [{ model: ItemCarrinho, as: 'itens', include: [{ model: Produto, as: 'produto' }] }],
        transaction
      });
      if (!carrinho || !carrinho.itens.length) {
        await transaction.rollback();
        return res.status(422).json({ message: 'O carrinho está vazio.' });
      }
      const total = carrinho.itens.reduce((soma, item) => soma + Number(item.produto.preco) * item.quantidade, 0);
      const venda = await Venda.create({ total: total.toFixed(2) }, { transaction });
      for (const item of carrinho.itens) {
        await ItemVenda.create({
          quantidade: item.quantidade,
          precoUnitario: item.produto.preco,
          VendaId: venda.id,
          ProdutoId: item.produto.id
        }, { transaction });
      }
      await carrinho.update({ status: 'finalizado' }, { transaction });
      await transaction.commit();
      return res.status(201).json({ message: 'Venda finalizada com sucesso!', vendaId: venda.id, total: venda.total });
    } catch (err) {
      await transaction.rollback();
      return res.status(500).json({ message: 'Erro ao finalizar venda.', error: err.message });
    }
  }

  static async listar(req, res) {
    try {
      const vendas = await Venda.findAll({
        include: [{ model: ItemVenda, as: 'itens', include: [{ model: Produto, as: 'produto' }] }],
        order: [['createdAt', 'DESC']]
      });
      return res.json(vendas);
    } catch (err) { return res.status(500).json({ message: 'Erro ao listar vendas.', error: err.message }); }
  }

  static async buscar(req, res) {
    try {
      const venda = await Venda.findByPk(req.params.id, {
        include: [{ model: ItemVenda, as: 'itens', include: [{ model: Produto, as: 'produto' }] }]
      });
      if (!venda) return res.status(404).json({ message: 'Venda não encontrada.' });
      return res.json(venda);
    } catch (err) { return res.status(500).json({ message: 'Erro ao buscar venda.', error: err.message }); }
  }
};
