const Produto = require('../model/Produto');

module.exports = class ProdutoController {
  static async create(req, res) {
    try {
      const { nome, preco } = req.body;
      if (!nome || !String(nome).trim()) return res.status(422).json({ message: 'O nome é obrigatório!' });
      if (preco === undefined || preco === '' || !Number.isFinite(Number(preco)) || Number(preco) < 0)
        return res.status(422).json({ message: 'Informe um preço válido (zero ou maior).' });
      const produto = await Produto.create({
        nome: String(nome).trim(), preco: Number(preco),
        imagem: req.file ? `/uploads/${req.file.filename}` : null
      });
      return res.status(201).json(produto);
    } catch (err) {
      return res.status(500).json({ message: 'Erro ao criar produto.', error: err.message });
    }
  }

  static async getAll(req, res) {
    try { return res.status(200).json(await Produto.findAll({ order: [['id', 'DESC']] })); }
    catch (err) { return res.status(500).json({ message: 'Erro ao buscar produtos.', error: err.message }); }
  }

  static async getById(req, res) {
    try {
      const produto = await Produto.findByPk(req.params.id);
      if (!produto) return res.status(404).json({ message: 'Produto não encontrado!' });
      return res.status(200).json(produto);
    } catch (err) { return res.status(500).json({ message: 'Erro ao buscar produto.', error: err.message }); }
  }

  static async update(req, res) {
    try {
      const produto = await Produto.findByPk(req.params.id);
      if (!produto) return res.status(404).json({ message: 'Produto não encontrado!' });
      const { nome, preco } = req.body;
      if (nome !== undefined && !String(nome).trim()) return res.status(422).json({ message: 'O nome é obrigatório!' });
      if (preco !== undefined && (preco === '' || !Number.isFinite(Number(preco)) || Number(preco) < 0))
        return res.status(422).json({ message: 'O preço não pode ser negativo.' });
      await produto.update({
        ...(nome !== undefined ? { nome: String(nome).trim() } : {}),
        ...(preco !== undefined ? { preco: Number(preco) } : {}),
        ...(req.file ? { imagem: `/uploads/${req.file.filename}` } : {})
      });
      return res.status(200).json(produto);
    } catch (err) { return res.status(500).json({ message: 'Erro ao atualizar produto.', error: err.message }); }
  }

  static async delete(req, res) {
    try {
      const produto = await Produto.findByPk(req.params.id);
      if (!produto) return res.status(404).json({ message: 'Produto não encontrado!' });
      await produto.destroy();
      return res.status(200).json({ message: 'Produto deletado com sucesso!' });
    } catch (err) { return res.status(500).json({ message: 'Erro ao deletar produto.', error: err.message }); }
  }
};
