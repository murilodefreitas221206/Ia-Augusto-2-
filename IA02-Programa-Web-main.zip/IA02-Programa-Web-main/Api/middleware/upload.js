const multer = require('multer');
const path = require('path');
const fs = require('fs');
const destino = path.join(__dirname, '..', 'uploads');
if (!fs.existsSync(destino)) fs.mkdirSync(destino, { recursive: true });

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, destino),
  filename: (_req, file, cb) => cb(null, `${Date.now()}-${Math.round(Math.random()*1e9)}${path.extname(file.originalname).toLowerCase()}`)
});
module.exports = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const mime = file.mimetype.toLowerCase();
    if (['.jpeg', '.png'].includes(ext) && ['image/jpeg', 'image/png'].includes(mime)) return cb(null, true);
    cb(new Error('A imagem deve estar no formato .jpeg ou .png.'));
  }
});
