const { DataTypes } = require('sequelize');
const db = require('../db/conn');

const ItemVenda = db.define('ItemVenda', {
  quantidade: { type: DataTypes.INTEGER, allowNull: false, validate: { min: 1 } },
  precoUnitario: { type: DataTypes.DECIMAL(10, 2), allowNull: false }
});

module.exports = ItemVenda;
