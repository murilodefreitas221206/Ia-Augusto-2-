const { DataTypes } = require('sequelize');
const db = require('../db/conn');

const Venda = db.define('Venda', {
  total: { type: DataTypes.DECIMAL(10, 2), allowNull: false, defaultValue: 0 },
  status: { type: DataTypes.STRING, allowNull: false, defaultValue: 'finalizada' }
});

module.exports = Venda;
