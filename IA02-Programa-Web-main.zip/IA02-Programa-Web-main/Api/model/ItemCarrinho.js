const { DataTypes } = require('sequelize');
const db = require('../db/conn');

const ItemCarrinho = db.define('ItemCarrinho', {
  quantidade: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 1, validate: { min: 1 } }
});

module.exports = ItemCarrinho;
