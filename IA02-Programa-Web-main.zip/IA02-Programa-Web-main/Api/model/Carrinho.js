const { DataTypes } = require('sequelize');
const db = require('../db/conn');

const Carrinho = db.define('Carrinho', {
  sessionId: { type: DataTypes.STRING, allowNull: false, unique: true },
  status: { type: DataTypes.STRING, allowNull: false, defaultValue: 'aberto' }
});

module.exports = Carrinho;
