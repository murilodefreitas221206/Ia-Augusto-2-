const router = require('express').Router();
const ProdutoController = require('../Controller/ProdutoController');
const upload = require('../middleware/upload');

router.post('/create', upload.single('imagem'), ProdutoController.create);
router.get('/getAll', ProdutoController.getAll);
router.get('/getById/:id', ProdutoController.getById);
router.patch('/update/:id', upload.single('imagem'), ProdutoController.update);
router.delete('/delete/:id', ProdutoController.delete);

module.exports = router;
