const router = require('express').Router();
const Controller = require('../Controller/VendaController');
router.post('/finalizar', Controller.finalizar);
router.get('/getAll', Controller.listar);
router.get('/getById/:id', Controller.buscar);
module.exports = router;
