const router = require('express').Router();
const Controller = require('../Controller/CarrinhoController');
router.get('/:sessionId', Controller.get);
router.post('/add', Controller.add);
router.patch('/item/:itemId', Controller.update);
router.delete('/item/:itemId', Controller.remove);
router.delete('/clear/:sessionId', Controller.clear);
module.exports = router;
