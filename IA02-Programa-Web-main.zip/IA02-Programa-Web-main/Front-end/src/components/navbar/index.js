import { Link, NavLink } from 'react-router-dom';
const NavBar = () => (
  <nav className="navbar">
    <div className="nav-inner">
      <Link className="brand" to="/home">LojaWeb</Link>
      <div className="nav-links">
        <NavLink to="/home">Início</NavLink>
        <NavLink to="/produtos">Produtos</NavLink>
      </div>
    </div>
  </nav>
);
export default NavBar;
