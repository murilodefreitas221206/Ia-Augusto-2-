const InputGroup = ({ type = 'text', placeholder, name, onChange, label, value, min, step, accept, required = false }) => (
  <div className="form-group">
    <label htmlFor={name}>{label}</label>
    <input id={name} className="form-control" type={type} placeholder={placeholder}
      name={name} onChange={onChange} value={value ?? ''} min={min} step={step}
      accept={accept} required={required} />
  </div>
);
export default InputGroup;
