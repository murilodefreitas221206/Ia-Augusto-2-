import { useEffect, useMemo, useState } from 'react';
import api from '../../util/api';

const sessionId = (() => {
  let id = localStorage.getItem('loja_session_id');
  if (!id) { id = `sessao-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`; localStorage.setItem('loja_session_id', id); }
  return id;
})();
const moeda = valor => Number(valor || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
const imagemUrl = imagem => imagem ? `${api.defaults.baseURL}${imagem}` : '';

const Home = () => {
  const [produtos, setProdutos] = useState([]);
  const [carrinho, setCarrinho] = useState(null);
  const [erro, setErro] = useState('');
  const [finalizando, setFinalizando] = useState(false);
  const itens = carrinho?.itens || [];
  const total = useMemo(() => itens.reduce((soma, item) => soma + Number(item.produto?.preco || 0) * item.quantidade, 0), [itens]);
  const quantidade = itens.reduce((soma, item) => soma + item.quantidade, 0);

  async function carregar() {
    try {
      const [p, c] = await Promise.all([api.get('/Produto/getAll'), api.get(`/Carrinho/${sessionId}`)]);
      setProdutos(p.data); setCarrinho(c.data); setErro('');
    } catch { setErro('Não foi possível conectar à loja. Confira se a API e o banco de dados estão funcionando.'); }
  }
  useEffect(() => { carregar(); }, []);

  async function adicionar(produtoId) {
    try {
      const response = await api.post('/Carrinho/add', { sessionId, produtoId, quantidade: 1 });
      setCarrinho(response.data);
    } catch (err) { setErro(err.response?.data?.message || 'Não foi possível adicionar o produto.'); }
  }
  async function alterar(itemId, novaQuantidade) {
    if (novaQuantidade < 1) return remover(itemId);
    try { const response = await api.patch(`/Carrinho/item/${itemId}`, { quantidade: novaQuantidade }); setCarrinho(response.data); }
    catch (err) { setErro(err.response?.data?.message || 'Erro ao atualizar quantidade.'); }
  }
  async function remover(itemId) {
    try { await api.delete(`/Carrinho/item/${itemId}`); await carregar(); }
    catch (err) { setErro(err.response?.data?.message || 'Erro ao remover item.'); }
  }
  async function finalizar() {
    if (!itens.length) return;
    setFinalizando(true); setErro('');
    try {
      const response = await api.post('/Venda/finalizar', { sessionId });
      alert(`${response.data.message}\nPedido #${response.data.vendaId}\nTotal: ${moeda(response.data.total)}`);
      await carregar();
    } catch (err) { setErro(err.response?.data?.message || 'Não foi possível finalizar a venda.'); }
    finally { setFinalizando(false); }
  }

  return <main className="container page">
    <section className="hero"><div><span className="eyebrow">SUA LOJA ONLINE</span><h1>Encontre o que você procura.</h1><p>Confira nossos produtos e adicione seus favoritos ao carrinho.</p></div><div className="hero-icon">🛍️</div></section>
    {erro && <p className="error-message">{erro}</p>}
    <div className="shop-layout">
      <section className="catalog"><div className="section-title"><div><span className="eyebrow">VITRINE</span><h2>Nossos produtos</h2></div><span>{produtos.length} item(ns)</span></div>
        <div className="product-grid">{produtos.length ? produtos.map(p => <article className="product-card" key={p.id}>
          {p.imagem ? <img className="product-image" src={imagemUrl(p.imagem)} alt={p.nome} /> : <div className="product-image product-no-image">📦</div>}
          <div className="product-info"><h3>{p.nome}</h3><strong>{moeda(p.preco)}</strong><button className="btn-primary full" onClick={() => adicionar(p.id)}>Adicionar ao carrinho</button></div>
        </article>) : <div className="empty-card">Ainda não há produtos cadastrados. Acesse Produtos para adicionar itens à loja.</div>}</div>
      </section>
      <aside className="cart panel"><div className="cart-heading"><div><span className="eyebrow">SEU PEDIDO</span><h2>Meu carrinho</h2></div><span className="cart-count">{quantidade}</span></div>
        {!itens.length ? <div className="cart-empty"><span>🛒</span><p>Seu carrinho está vazio.</p><small>Adicione produtos para começar.</small></div> : <>
          <div className="cart-items">{itens.map(item => <div className="cart-item" key={item.id}>
            <div className="cart-item-main"><strong>{item.produto?.nome || 'Produto'}</strong><small>{moeda(item.produto?.preco)} cada</small></div>
            <div className="quantity"><button onClick={() => alterar(item.id, item.quantidade - 1)} aria-label="Diminuir">−</button><span>{item.quantidade}</span><button onClick={() => alterar(item.id, item.quantidade + 1)} aria-label="Aumentar">+</button></div>
            <button className="remove-link" onClick={() => remover(item.id)}>Remover</button>
          </div>)}</div>
          <div className="cart-total"><span>Total</span><strong>{moeda(total)}</strong></div>
          <button className="btn-primary full checkout" onClick={finalizar} disabled={finalizando}>{finalizando ? 'Finalizando...' : 'Finalizar compra'}</button>
          <p className="secure-note">Ao finalizar, a venda será registrada no sistema.</p>
        </>}
      </aside>
    </div>
  </main>;
};
export default Home;
