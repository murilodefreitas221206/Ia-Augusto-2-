import { useEffect, useState } from 'react';
import InputGroup from '../../components/inputGroup';
import useProduto from '../../hooks/useProduto';

const Produtos = () => {
  const { getAll, create, update, remove } = useProduto();
  const [produto, setProduto] = useState({ nome: '', preco: '' });
  const [imagem, setImagem] = useState(null);
  const [lstProdutos, setLstProdutos] = useState([]);
  const [editando, setEditando] = useState(null);
  const [erro, setErro] = useState('');

  async function carregarProdutos() {
    try { setLstProdutos(await getAll()); } catch { setErro('Não foi possível carregar os produtos. Verifique se a API está ligada.'); }
  }
  useEffect(() => { carregarProdutos(); }, []);

  function handleChange(e) { setProduto(prev => ({ ...prev, [e.target.name]: e.target.value })); }
  function handleImagem(e) {
    const arquivo = e.target.files[0];
    if (arquivo && !['image/jpeg', 'image/png'].includes(arquivo.type)) {
      setErro('Selecione somente imagens .jpeg ou .png.'); e.target.value = ''; setImagem(null); return;
    }
    setErro(''); setImagem(arquivo || null);
  }
  async function handleSubmit(e) {
    e.preventDefault(); setErro('');
    if (!produto.nome.trim()) return setErro('Informe o nome do produto.');
    if (produto.preco === '' || !Number.isFinite(Number(produto.preco)) || Number(produto.preco) < 0)
      return setErro('O preço deve ser zero ou maior.');
    const dados = new FormData();
    dados.append('nome', produto.nome.trim()); dados.append('preco', produto.preco);
    if (imagem) dados.append('imagem', imagem);
    try {
      if (editando) await update(editando, dados); else await create(dados);
      setProduto({ nome: '', preco: '' }); setImagem(null); setEditando(null);
      e.target.reset(); await carregarProdutos();
    } catch (err) { setErro(err.response?.data?.message || 'Erro ao salvar produto.'); }
  }
  function editar(item) {
    setEditando(item.id); setProduto({ nome: item.nome, preco: item.preco });
    setImagem(null); window.scrollTo({ top: 0, behavior: 'smooth' });
  }
  async function excluir(id) {
    if (!window.confirm('Deseja realmente excluir este produto?')) return;
    try { await remove(id); await carregarProdutos(); } catch (err) { setErro(err.response?.data?.message || 'Erro ao excluir produto.'); }
  }

  return <main className="container page">
    <div className="page-heading"><div><span className="eyebrow">ADMINISTRAÇÃO</span><h1>Produtos</h1><p>Cadastre e gerencie os produtos da sua loja.</p></div></div>
    <section className="panel">
      <h2>{editando ? 'Editar produto' : 'Cadastrar produto'}</h2>
      <form onSubmit={handleSubmit} className="product-form">
        <InputGroup label="Nome do produto" name="nome" value={produto.nome} onChange={handleChange} placeholder="Ex.: Camiseta básica" required />
        <InputGroup label="Preço (R$)" name="preco" type="number" min="0" step="0.01" value={produto.preco} onChange={handleChange} placeholder="0,00" required />
        <InputGroup label="Imagem (.jpeg ou .png)" name="imagem" type="file" accept=".jpeg,.png,image/jpeg,image/png" onChange={handleImagem} />
        <div className="form-actions"><button className="btn-primary" type="submit">{editando ? 'Salvar alterações' : 'Cadastrar produto'}</button>
          {editando && <button className="btn-light" type="button" onClick={() => {setEditando(null);setProduto({nome:'',preco:''});setImagem(null);}}>Cancelar</button>}</div>
      </form>
      {erro && <p className="error-message">{erro}</p>}
    </section>
    <section className="panel">
      <div className="section-title"><h2>Produtos cadastrados</h2><span>{lstProdutos.length} produto(s)</span></div>
      <div className="table-wrap"><table><thead><tr><th>Imagem</th><th>Produto</th><th>Preço</th><th>Ações</th></tr></thead>
        <tbody>{lstProdutos.length ? lstProdutos.map(item => <tr key={item.id}>
          <td>{item.imagem ? <img className="table-image" src={`http://localhost:5000${item.imagem}`} alt={item.nome} /> : <div className="image-placeholder">Sem imagem</div>}</td>
          <td>{item.nome}</td><td>{Number(item.preco).toLocaleString('pt-BR',{style:'currency',currency:'BRL'})}</td>
          <td className="actions"><button className="btn-small" onClick={() => editar(item)}>Editar</button><button className="btn-small danger" onClick={() => excluir(item.id)}>Excluir</button></td>
        </tr>) : <tr><td colSpan="4" className="empty">Nenhum produto cadastrado.</td></tr>}</tbody>
      </table></div>
    </section>
  </main>;
};
export default Produtos;
