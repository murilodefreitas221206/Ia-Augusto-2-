# LojaWeb — Projeto de Programação Web

Projeto desenvolvido a partir da estrutura utilizada em sala, mantendo a separação entre `Api` (Node.js/Express/Sequelize) e `Front-end` (React).

## Requisitos
- Node.js e npm
- MariaDB
- Banco de dados chamado `loja`

## Configuração da API
1. Entre na pasta `Api`.
2. Instale as dependências: `npm install`.
3. Copie `.env.example` para `.env` e ajuste usuário/senha do MariaDB.
4. Crie o banco: `CREATE DATABASE loja;`.
5. Inicie a API: `npm run dev` (ou `npm start`).

A API ficará disponível em `http://localhost:5000`. As tabelas são sincronizadas pelo Sequelize ao iniciar.

## Configuração do Front-end
1. Em outro terminal, entre em `Front-end`.
2. Execute `npm install`.
3. Execute `npm start`.
4. Acesse `http://localhost:3000/home`.

Se a API estiver hospedada em outro endereço, configure `REACT_APP_API_URL` antes de iniciar o React.

## Funcionalidades
- CRUD de produtos integrado à API.
- Cadastro de imagem de produto, aceitando somente `.jpeg` e `.png` (limite de 5 MB).
- Validação de preço para impedir valores negativos, tanto no front-end quanto na API.
- Vitrine de produtos na rota `/home`.
- Carrinho persistido na API por identificador de sessão do navegador.
- Alteração de quantidade, remoção de itens e finalização de venda.
- Registro das vendas e dos itens vendidos no MariaDB.

## Endpoints

### Produtos — prefixo `/Produto`
- `POST /create` — cria produto (`multipart/form-data`: `nome`, `preco`, `imagem` opcional).
- `GET /getAll` — lista produtos.
- `GET /getById/:id` — consulta produto.
- `PATCH /update/:id` — atualiza produto.
- `DELETE /delete/:id` — exclui produto.

### Carrinho — prefixo `/Carrinho`
- `GET /:sessionId` — consulta/cria carrinho aberto.
- `POST /add` — recebe `{ "sessionId": "...", "produtoId": 1, "quantidade": 1 }`.
- `PATCH /item/:itemId` — recebe `{ "quantidade": 2 }`.
- `DELETE /item/:itemId` — remove item.
- `DELETE /clear/:sessionId` — limpa carrinho.

### Vendas — prefixo `/Venda`
- `POST /finalizar` — recebe `{ "sessionId": "..." }` e registra a venda.
- `GET /getAll` — lista vendas.
- `GET /getById/:id` — consulta uma venda.

## Publicação no GitHub
Crie um repositório público no GitHub e envie a pasta do projeto. Não envie a pasta `node_modules` nem o arquivo `.env`.
